from scrapy import Request, Spider
from ..items import PostersItem
import requests
from bs4 import BeautifulSoup
import urllib.request
import os


class PostersSpider(Spider):
    name = 'postersSpider'
    #start_urls = ['https://www.imdb.com/search/title/?genres=horror&sort=user_rating,desc&title_type=feature&num_votes=25000,','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=51&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=101&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=151&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=201&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=251&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=301&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=351&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=401&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=451&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=501&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=551&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=601&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&num_votes=25000,&genres=horror&sort=user_rating,desc&start=651&ref_=adv_nxt']
    #start_urls =['https://www.imdb.com/search/title/?genres=comedy&groups=top_1000&sort=user_rating&title_type=feature','https://www.imdb.com/search/title/?title_type=feature&genres=comedy&groups=top_1000&sort=user_rating,desc&start=51&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&genres=comedy&groups=top_1000&sort=user_rating,desc&start=101&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&genres=comedy&groups=top_1000&sort=user_rating,desc&start=151&ref_=adv_nxt','https://www.imdb.com/search/title/?title_type=feature&genres=comedy&groups=top_1000&sort=user_rating,desc&start=201&ref_=adv_nxt','https://www.imdb.com/list/ls063960951/','https://www.imdb.com/list/ls057433882/','https://www.imdb.com/list/ls000038386/']
    #start_urls =['https://www.imdb.com/list/ls058726648/','https://www.imdb.com/list/ls058726648/','https://www.imdb.com/list/ls003094541/','https://www.imdb.com/list/ls056486778/','https://www.imdb.com/list/ls058265950/']
    start_urls=['https://www.imdb.com/search/title/?lists=ls027328830&count=100&start=101&ref_=adv_nxt','https://www.imdb.com/search/title/?lists=ls027328830&count=100&start=201&ref_=adv_nxt','https://www.imdb.com/search/title/?lists=ls027328830&count=100&start=301&ref_=adv_nxt','https://www.imdb.com/search/title/?lists=ls027328830&count=100&start=401&ref_=adv_nxt']

    def start_requests(self):
        for url in self.start_urls:
            yield Request(url=url, callback=self.parse_films)

    def parse_films(self, response):

        soupTop = BeautifulSoup(response.text, 'html.parser')

        UrlMovie = []
        title = []
        genre = []
        imageURL = []

        titleSection = soupTop.find_all('h3', {'class': 'lister-item-header'})

        # Recuperation des URL de chaque page des films
        for i in titleSection:
            UrlMovie.append(i.find('a')['href'])

        # Boucle sur les pages de films
        for url in UrlMovie:
            rep= requests.get('https://www.imdb.com' + url)
            soup = BeautifulSoup( rep.text, 'html.parser')


            # Recuperation des titres
            titleSectionMoviePage = soup.find('h1')
            tmpTitle = ''
            if titleSectionMoviePage.text.strip().find(u"\u00A0") != -1:
                tmpTitle=titleSectionMoviePage.text.strip()[:titleSectionMoviePage.text.strip().find(u"\u00A0")]
            else :
                tmpTitle= titleSectionMoviePage.text.strip()
            title.append(tmpTitle)

            # Recuperation des genres
            genreSection = soup.find_all('h4', {'class': 'inline'})
            g = ''
            for i in genreSection:
                if (i.text.strip() == 'Genres:'):

                    lis_genres = i.parent.find_all('a')
                    for j in lis_genres:
                        g+=j.text.strip()+','
                    break
            genre.append(g[:-1])

            # Recuperation des images

            imgSection = soup.find('div', {'class': 'poster'})
            img = imgSection.a.img['src']
            t = title[len(title) - 1]
            for i in '<>:“/\\|?*.':
                if i in t:
                    t = t.replace(i, '')

            t = t.replace(' ', '_')

            if not os.path.isfile('C/' +t + '.png') or not os.path.isfile('H/' +t + '.png'):
                urllib.request.urlretrieve(img, 'A/' + t + '.png')
            else:
                t = '_' + t
                urllib.request.urlretrieve(img, 'A/' + t + '.png')


        for ti, ge in zip(title, genre):
            yield {
                'title': ti,
                'genre': ge
            }

